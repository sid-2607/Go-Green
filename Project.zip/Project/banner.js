const swiper = new Swiper('.banner-container', {
    slidesPerView: 1,
    spaceBetween: 20,
    loop: true,
    navigation: {
      nextEl: '.next',
      prevEl: '.previous',
    },
  });
  