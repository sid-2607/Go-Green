const carousel = document.querySelector(".carousel");
const cards = document.querySelectorAll(".SDG_box");
const leftButton = document.getElementById("left");
const rightButton = document.getElementById("right");

let currentIndex = 0;
let isPaused = false;

rightButton.addEventListener("click", () => {
    if (currentIndex < cards.length - 1) {
        currentIndex++;
    } else {
        currentIndex = 0;
    }
    pauseAutoScroll();
    scrollCarousel();
});

leftButton.addEventListener("click", () => {
    if (currentIndex > 0) {
        currentIndex--;
    } else {
        currentIndex = cards.length - 1;
    }
    pauseAutoScroll();
    scrollCarousel();
});

function scrollCarousel() {
    const cardWidth = cards[0].offsetWidth;
    carousel.scrollLeft = currentIndex * cardWidth;
}

function autoScroll() {
    if (!isPaused) {
        if (currentIndex < cards.length - 1) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        scrollCarousel();
    }
}

function pauseAutoScroll() {
    isPaused = true;
    setTimeout(() => {
        isPaused = false;
    }, 3000); // Adjust the delay time (in milliseconds) as needed
}

carousel.addEventListener("mouseenter", () => {
    pauseAutoScroll();
});

carousel.addEventListener("mouseleave", () => {
    isPaused = false;
});

cards.forEach((card) => {
    card.addEventListener("mouseenter", () => {
        pauseAutoScroll();
    });

    card.addEventListener("mouseleave", () => {
        isPaused = false;
    });
});

setInterval(autoScroll, 10000);
